package com.EmployeeDataManagement.EmployeeDataManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeDataManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
