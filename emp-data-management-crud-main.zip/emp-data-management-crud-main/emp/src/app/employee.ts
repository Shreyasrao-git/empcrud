export class Employee {
    id: number=0;
    firstname: string="";
    lastname: string="";
    email: string="";
    salary: number=0;
}
